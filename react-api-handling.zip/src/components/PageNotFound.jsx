import React from 'react'

const PageNotFound = () => {
    return (
        <div>
            <h2>Sorry! 404 Page is not found</h2>
        </div>
    )
}

export default PageNotFound
