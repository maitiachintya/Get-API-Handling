// https://jsonplaceholder.typicode.com/users

export const baseUrl = "https://jsonplaceholder.typicode.com"

export const userEnd = "/users"

export const end_points = {
    users: "/users"
}