// https://fakestoreapi.com/products

export const baseUrl = "https://fakestoreapi.com"

// export const userEnd = "/products"

export const end_points = {
    items: "/products",
    categories: "/categories"
}