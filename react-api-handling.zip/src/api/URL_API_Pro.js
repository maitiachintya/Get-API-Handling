// https://dummyjson.com/products

export const baseUrl = "https://dummyjson.com"

export const userEnd = "/products"

export const end_points = {
    products: "/products"
}